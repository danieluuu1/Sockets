import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Servidor {
    public static void main(String[] args) {
        ServerSocket servidor = null;
        Socket sc = null;
        DataInputStream in;
        DataOutputStream out;
        System.out.println("Servidor iniciado");
        final int PUERTO = 6000;

        try {
            servidor = new ServerSocket(PUERTO);
            while (true) {
                sc = servidor.accept();
                System.out.println("Cliente conectado");

                in = new DataInputStream(sc.getInputStream());
                out = new DataOutputStream(sc.getOutputStream());

                // Leer mensaje del cliente
                String mensaje = in.readUTF();
                System.out.println("Recibido: " + mensaje);

                // Procesar los datos recibidos
                String[] datos = mensaje.split(", ");
                String nombreCompleto = datos[0];
                int edad = Integer.parseInt(datos[1]);

                // Verificar la mayoría de edad
                String respuesta = nombreCompleto + " es " + (edad >= 18 ? "mayor" : "menor") + " de edad";

                // Enviar respuesta al cliente
                out.writeUTF(respuesta);

                sc.close();
                System.out.println("Cliente desconectado");
            }

        } catch (IOException ex) {
            Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}


