import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class Cliente {
    public static void main(String[] args) {
        final String HOST = "localhost";
        final int PUERTO = 6000;
        DataInputStream in;
        DataOutputStream out;

        try {
            Socket sc = new Socket(HOST, PUERTO);

            in = new DataInputStream(sc.getInputStream());
            out = new DataOutputStream(sc.getOutputStream());

            // Solicitar datos del usuario
            String nombre = JOptionPane.showInputDialog(null, "Ingrese su nombre:", "Entrada de datos", JOptionPane.QUESTION_MESSAGE);
            String apellidos = JOptionPane.showInputDialog(null, "Ingrese sus apellidos:", "Entrada de datos", JOptionPane.QUESTION_MESSAGE);
            String edadStr = JOptionPane.showInputDialog(null, "Ingrese su edad:", "Entrada de datos", JOptionPane.QUESTION_MESSAGE);
            
            int edad = 0;
            try {
                edad = Integer.parseInt(edadStr);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Edad inválida. Debe ser un número entero.", "Error", JOptionPane.ERROR_MESSAGE);
                sc.close();
                return;
            }

            // Enviar datos al servidor
            out.writeUTF(nombre + " " + apellidos + ", " + edad);

            // Recibir respuesta del servidor
            String mensaje = in.readUTF();
            JOptionPane.showMessageDialog(null, mensaje, "Respuesta del servidor", JOptionPane.INFORMATION_MESSAGE);

            sc.close();

        } catch (IOException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}


